<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
a {
    text-decoration: none;
    color: #666666;
    text-transform: capitalize;
    text-decoration: none;
    transition: color 0.35s ease-in-out;
    word-wrap: break-word;
    font-size:35px;
}
.logo{
    text-align:center;
}
</style>
<body>
    <div class="logo">
        <h2><a href="index.php">ELECTRO</a></h2>
    </div>
    
</body>
</html>