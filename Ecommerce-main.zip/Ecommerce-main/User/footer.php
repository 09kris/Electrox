<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<link rel="stylesheet" href="Assets/css/footer.css">
<body>
<footer>
        <div class="f-footer" id="MyFoot">
            <div class="footer-x">
                <h4>CONTACT INFOMATION</h4>
                <p>Call Us 24/7 Free</p>
                <h1>1 001 234 5678</h1>
                <p>Support@domain.com</p>
                <p>3,Ambik chok,Deesa 385535,Gujrat,India</p>
            </div>
            <div class="footer-y">
                <h4>COMPANY</h4>
                <a href="">About Us</a>
                <a href="">Shop Products</a>
                <a href="">My Cart</a>
                <a href="">Checkout</a>
                <a href="">Contact Us</a>
                <a href="">Order Tracking</a>

            </div>
            <div class="footer-y">
                <h4>EXPLORE</h4>
                <a href="">Gift a Smile</a>
                <a href="">Creybit Cares</a>
                <a href="">Size Guide</a>
                <a href="">F.A.Q.’s</a>
                <a href="">Privacy Policy</a>
                <a href="">Store Location</a>
            </div>
            <div class="footer-x">
                <h4>OUR LOCATION</h4>
                <a href=""> <img src="Assets/img/banner1.jpg" alt=""></a>
            </div>
        </div>
        <div class="x-footer">
            <div class="x-footer-x">copyright &copy; 2021 Creybit All Rights
                Reserved.</div>
        </div>
    </footer>
</body>
</html>